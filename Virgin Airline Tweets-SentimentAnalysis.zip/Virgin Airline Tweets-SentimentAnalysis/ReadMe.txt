
Implementation steps:
----------------------------  
     ­ -Collecting data that contains text .
     ­ -Convert data into better format to access its columns and rows.
     ­ -Visualize data to see if they are a missing values or not .
­      -Filter data from missing values and clean data from English  
       StopWords.
     ­ -Tokenize data and clean undesired characters and numbers..
     ­ -Initialize the model for text data analysis using NLP techniques.
­      -Embedding the text tokenized words into the model (using my own 
       trained model not pre­trained one).
     ­ -Convert the word embedding array into feature vector.
     ­ -Using an algorithm to transform desired classes into numeric labels.
     ­ -Split the data into train data and test data using 20­-80 approach.
­      -Using a supervised learning classification algorithm to predict the 
       output of  the feature vectors or training data.
­      -Using f1 score , recall and precision to evaluate quality of the 	model.

Python Libraries used for pre­processing and classification:
--------------------------------------------------------------
­ pandas (Dataframes – CSV reader)
­ Numpy
­ Dictionaries
­ NLTK (tokenizer - word2vec for word embedding)
­ Sklearn (Random forest – Train­test­split – accuracy score ­f1score)
 regular expressions 

note: i didn't use transfer learning approach like a pre-trained model google vectors (about 2 milion english words included) as laptop preformance is low, it will take too long to load and the model size is about 2.00GB
