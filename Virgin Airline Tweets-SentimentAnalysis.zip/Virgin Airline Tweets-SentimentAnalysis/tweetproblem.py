from nltk.corpus import stopwords
from gensim.models import Word2Vec
import nltk
import re
import pandas as pd
import numpy as np
from MeanWord2vec import MeanEmbeddingVectorizer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import precision_recall_fscore_support
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score

import gensim
# Preprocessing and tokenization of the data
xtrain = []
data = pd.read_csv('Tweets.csv', engine='python',index_col='tweet_id')
index = data.index

df = pd.DataFrame(data).dropna(axis='rows')
id = []
extrawords = ['figure', 'fig', 'author']
stop_words = stopwords.words('english') + extrawords

print('tokenization started')
x = df['text']
y = df['airline_sentiment']
tokenized_data = [nltk.word_tokenize(re.sub(r'[^\w\s]', '', sent).lower()) for sent in x]
filtered_data = [[w for w in sent if w not in stop_words] for sent in tokenized_data]

for i in filtered_data:
    xtrain.append(i)

model = Word2Vec(xtrain , window=5)
meanvects = MeanEmbeddingVectorizer(model)
words = meanvects.fit_transform(filtered_data)

labeling = LabelEncoder()
Y = labeling.fit_transform(y.astype('str'))
df['y_categorical'] = Y

x_train , x_test , y_train , y_test = train_test_split(words,Y,stratify=Y,test_size=0.20)

clf = RandomForestClassifier(n_estimators=20,random_state=0)

fit = clf.fit(x_train,y_train)

preds = clf.predict(x_test)
f1score = precision_recall_fscore_support(y_test, preds, average='macro')
print(f1score)

cross_validation_score = np.mean(cross_val_score(clf , words , Y, cv=3))
print(cross_validation_score)
